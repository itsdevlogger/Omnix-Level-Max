﻿using UnityEngine;
namespace DialogueSystem
{
    public abstract class OptionUiBase : MonoBehaviour
    {
        public abstract void Set(Question question, Option option);
    }
}
﻿using UnityEngine;
namespace DialogueSystem
{
    public abstract class QuestionUiBase : MonoBehaviour
    {
        public abstract string Text { set; }
        public abstract int MaxVisibleCharacters { set; }
    }
}
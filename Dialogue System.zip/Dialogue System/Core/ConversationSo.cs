using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace DialogueSystem
{
    [CreateAssetMenu(menuName = "Conversation", fileName = "New Conversation")]
    public class ConversationSo : ScriptableObject
    {
        public Question starter;
        public Question[] questions;

        public DialogueFlow GetFlow()
        {
            return new DialogueFlow()
            {
                Starter = this.starter,
                Questions = this.questions.ToDictionary(q => q.id)
            };
        }
    }
}
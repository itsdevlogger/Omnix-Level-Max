﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using Object = UnityEngine.Object;

namespace DialogueSystem
{
    [Serializable]
    public class Option
    {
        public string targetId;
        public string message;

        public Option(string targetId, string message)
        {
            this.targetId = targetId;
            this.message = message;
        }
    }

    [Serializable]
    public class Command
    {
        public string name;
        public int mark;

        public Command(string name, int mark)
        {
            this.name = name;
            this.mark = mark;
        }

    }

    [Serializable]
    public class Condition
    {
        public string variableName;
        public string comparedValue;
        public Operation operation;
    }
    
    [Serializable]
    public class Question
    {
        public string id;
        public string[] messages;
        public Option[] options;
    }

    [Serializable]
    public class VariableReference
    {
        public object value;
        public VariableType type;

        public VariableReference(object value, VariableType type)
        {
            this.value = value;
            this.type = type;
        }

        [JsonIgnore] public bool IsNumeric => type == VariableType.Int || type == VariableType.Float;
        [JsonIgnore] public bool IsBool => type == VariableType.Bool;
        [JsonIgnore] public bool IsString => type == VariableType.String;
    }

    [Serializable]
    public class DialogueFlow
    {
        public Question Starter;
        public Dictionary<string, VariableReference> Variables;
        public Dictionary<string, Question> Questions;

        public Question GetQuestion(string id)
        {
            if (Starter.id == id) return Starter;
            if (Questions.ContainsKey(id)) return Questions[id];
            return null;
        }
    }

    public enum Operation
    {
        Less,
        LessOrEqual,
        Equal,
        NotEqual,
        GreaterOrEqual,
        Greater
    }

    public enum VariableType
    {
        Int = 0,
        Float = 1,
        String = 2,
        Bool = 3,
        Linked = 4
    }
}
using System;
using UnityEngine.Events;

namespace DialogueSystem
{
    public static class DialogueEvents
    {
        // @formatter:off
        public static readonly UnityEvent<DialogueFlow          > OnBeginConversation    = new UnityEvent<DialogueFlow>();
        public static readonly UnityEvent<Question              > OnBeginQuestion        = new UnityEvent<Question>();
        public static readonly UnityEvent<Question, string      > OnDisplayQuestionText  = new UnityEvent<Question, string>();
        public static readonly UnityEvent<Question              > OnDisplayOptions       = new UnityEvent<Question>();
        public static readonly UnityEvent<Question              > OnEndQuestion          = new UnityEvent<Question>();
        public static readonly UnityEvent<Question, string      > OnExecuteCommand       = new UnityEvent<Question, string>();
        public static readonly UnityEvent                         OnEndConversation      = new UnityEvent();
        public static Func<Question, Condition, bool> ConditionChecker; 
        // @formatter:on
    }

}
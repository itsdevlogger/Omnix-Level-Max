using System.Data;
using DialogueSystem.Interpreter;
using UnityEngine;

namespace DialogueSystem
{
    public class DialoguesHandler : MonoBehaviour
    {
        public static DialoguesHandler Instance { get; private set; }

        public DialogueFlow CurrentFlow { get; private set; }
        public Question CurrentQuestion { get; private set; }

        [SerializeField] private QuestionUiBase questionsUi;
        [SerializeField, Tooltip("Delay in second after every character is printed.")]
        private float defaultWaitPerCharacter = 0.02f;
        [SerializeField, Tooltip("Delay in second after every question is displayed.")]
        private float defaultWaitPerQuestion = 2f;

        private WaitForSeconds _waitPerCharacter;
        private float _addedDelay = -1;

        private void Awake()
        {
            if (Instance != null)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
        }

        public void BeginQuestion(string questionId)
        {
            Question question = CurrentFlow.GetQuestion(questionId);
            if (question != null) BeginQuestion(question);
        }

        public void BeginQuestion(Question question)
        {
            if (CurrentQuestion != null) return;
            CurrentQuestion = question;
            StartCoroutine(QuestionDisplay.Display(CurrentQuestion, questionsUi, defaultWaitPerCharacter, defaultWaitPerQuestion));
        }

        public void EndQuestion()
        {
            StopAllCoroutines();
            if (CurrentQuestion == null) return;

            DialogueEvents.OnEndQuestion?.Invoke(CurrentQuestion);
            CurrentQuestion = null;
        }

        public void BeginConversation(ConversationSo conversation)
        {
            BeginConversation(conversation.GetFlow());
        }

        public void BeginConversation(string dialogueScript)
        {
            try
            {
                DialogueFlow dialogueFlow = DialogueInterpreter.Read(dialogueScript);
                BeginConversation(dialogueFlow);
            }
            catch (SyntaxErrorException e)
            {
                Debug.LogError($"{e.Message}\n{e.StackTrace}");
            }
        }

        public void BeginConversation(DialogueFlow conversation)
        {
            CurrentFlow = conversation;
            DialogueEvents.OnBeginConversation?.Invoke(conversation);
            BeginQuestion(CurrentFlow.Starter);
        }

        public void EndConversation()
        {
            CurrentFlow = null;
            CurrentQuestion = null;
            DialogueEvents.OnEndConversation?.Invoke();
        }
    }
}
using DialogueSystem;
using UnityEngine;

public class InteractOnTrigger : MonoBehaviour
{
    // [SerializeField] private ExtensionImporter.DialogueScriptAsset scriptAsset;

    private void OnTriggerEnter(Collider other)
    {
        // DialogueFlow flow = scriptAsset.GetFlow();
        // if (flow != null)
        // {
            // ConversationHandler.Instance.BeginConversation(flow);
        // }
    }
}

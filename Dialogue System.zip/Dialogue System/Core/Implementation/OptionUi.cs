using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DialogueSystem
{
    [RequireComponent(typeof(Button))]
    public class OptionUi : OptionUiBase
    {
        [SerializeField] private TextMeshProUGUI target;

        [NonSerialized] public Question question;
        [NonSerialized] public Option option;
        
        private void OnButtonClicked()
        {
            DialoguesHandler.Instance.EndQuestion();
            if (!string.IsNullOrEmpty(option.targetId))
            {
                DialoguesHandler.Instance.BeginQuestion(option.targetId);
            }
        }

        public override void Set(Question question, Option option)
        {
            target.text = option.message;
            this.question = question;
            this.option = option;
            GetComponent<Button>().onClick.AddListener(OnButtonClicked);
        }
    }
}

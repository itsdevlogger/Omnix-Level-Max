using TMPro;
using UnityEngine;

namespace DialogueSystem
{
    public class QuestionsUi : QuestionUiBase
    {
        [SerializeField] private OptionUiBase optionPrefab;
        [SerializeField] private Transform optionsParent;
        [SerializeField] private GameObject targetObject;
        [SerializeField] private TextMeshProUGUI target;

        public override string Text
        {
            set => target.text = value;
        }

        public override int MaxVisibleCharacters
        {
            set
            {
                target.maxVisibleCharacters = value;
                target.ForceMeshUpdate();
            }
        }
        
        private void OnEnable()
        {
            DialogueEvents.OnBeginQuestion.AddListener(OnBeginQuestion);
            DialogueEvents.OnDisplayOptions.AddListener(OnDisplayOptions);
            DialogueEvents.OnEndQuestion.AddListener(OnEndQuestion);
            DialogueEvents.OnEndConversation.AddListener(OnEndConversation);
        }

        private void OnDisable()
        {
            DialogueEvents.OnBeginQuestion.RemoveListener(OnBeginQuestion);
            DialogueEvents.OnDisplayOptions.RemoveListener(OnDisplayOptions);
            DialogueEvents.OnEndQuestion.RemoveListener(OnEndQuestion);
            DialogueEvents.OnEndConversation.RemoveListener(OnEndConversation);
        }

        private void Cleanup()
        {
            foreach (Transform child in optionsParent)
            {
                Destroy(child.gameObject);
            }
        }

        private void OnDisplayOptions(Question question)
        {
            Cleanup();
            if (question.options == null) return;
            
            
            foreach (Option option in question.options)
            {
                OptionUiBase optionUi = Instantiate(optionPrefab, optionsParent);
                optionUi.Set(question, option);
            }
        }

        private void OnBeginQuestion(Question question)
        {
            targetObject.SetActive(true);
        }
        
        private void OnEndQuestion(Question question)
        {
            Cleanup();
            targetObject.SetActive(false);
        }

        private void OnEndConversation()
        {
            Cleanup();
            targetObject.SetActive(false);
        }
    }
}
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using DialogueSystem;
using DialogueSystem.Interpreter;
using UnityEngine;

public static class QuestionDisplay
{
    private static WaitForSeconds _wpChara, _wpMessage;
    private static float _defWpChara, _defWpLine, _addedDelay;
    private static QuestionUiBase _questionsUi;
    private static Question _question;

    public static IEnumerator Display(Question question, QuestionUiBase questionsUi, float waitPerCharacter, float waitPerLine)
    {
        DialogueEvents.OnBeginQuestion?.Invoke(question);
        if (question.messages == null || question.messages.Length == 0)
        {
            DialogueEvents.OnDisplayOptions?.Invoke(question);
            yield break;
        }

        _wpChara = new WaitForSeconds(waitPerCharacter);
        _wpMessage = new WaitForSeconds(waitPerLine);
        _questionsUi = questionsUi;

        foreach (string questionText in question.messages)
        {
            yield return DisplayLine(questionText);

            if (_addedDelay > 0)
            {
                yield return new WaitForSeconds(_addedDelay);
                _addedDelay = -1;
            }
            yield return _wpMessage;
        }

        DialogueEvents.OnDisplayOptions?.Invoke(question);
    }

    private static IEnumerator DisplayLine(string line)
    {
        string lineStripped = StripLine(line);
        _questionsUi.Text = lineStripped;
        for (int i = 1; i < lineStripped.Length; i++)
        {
            _questionsUi.MaxVisibleCharacters = i;
            yield return _wpChara;
        }
    }

    private static void ExecuteCommand(string command)
    {
        if (command == "esc")
        {
            DialoguesHandler.Instance.EndConversation();
            return;
        }

        Match match = Syntax.Commands.Goto.Match(command);
        if (match.Success)
        {
            DialoguesHandler.Instance.EndQuestion();
            DialoguesHandler.Instance.BeginQuestion(match.Groups[1].Value);
            return;
        }

        match = Syntax.Commands.Speed.Match(command);
        if (match.Success)
        {
            float value = float.Parse(match.Groups[1].Value);
            _wpChara = new WaitForSeconds(_defWpChara / value);
            return;
        }

        match = Syntax.Commands.Wait.Match(command);
        if (match.Success)
        {
            _addedDelay = float.Parse(match.Groups[1].Value);
            return;
        }

        DialogueEvents.OnExecuteCommand?.Invoke(_question, command);
    }
}


public class StrippedLine
{
    public string Text;
    public List<(int, string)> Commands;
}

public static class LineStripper
{
    private static DialogueFlow _flow;
    private static StrippedLine _stripped;
    
    private static int _i;
    private static string _line;
    
    private static StrippedLine StripLine(string line, DialogueFlow flow)
    {
        _i = 0;
        _line = line;
        _flow = flow;
        _stripped = new StrippedLine
        {
            Commands = new List<(int, string)>(),
        };

        char c;
        if (line.StartsWith('{'))
        {
            ExtractScripts();
        }

        for (; _i < line.Length; _i++)
        {
            c = line[_i];
            
        }

        return _stripped;
    }

    private static void ExtractScripts()
    {
        StringBuilder builder = new StringBuilder();
        char c;
        while (_i < _line.Length)
        {
            _i++;
            c = _line[_i];
            if (c == ';')
            {
                ExecuteScript(builder.ToString());
                builder.Clear();
                continue;
            }
            if (c == '}')
            {
                _i++;
                break;
            }
            builder.Append(c);
        }
        ExecuteScript(builder.ToString());
        builder.Clear();
    }

    private static string ExtractVariableValue()
    {
        StringBuilder builder = new StringBuilder();   
        char c;
        while (_i < _line.Length)
        {
            _i++;
            c = _line[_i];
            if (c == '}')
            {
                _i++;
                break;
            }
            builder.Append(c);
        }
        
    }

    
    private static void ExecuteScript(string script)
    {
        
    }
    
}


/*
public static class ScriptExecutor
{
    /// <summary>
    /// Executes everything in between { and } including ifs and multiple commands split by ;
    /// </summary>
    /// <returns>True if the further execution of question is not necessary, i.e. the condition for displaying this line is not met. </returns>
    public static bool Execute(string script) => script.Split(';').Any(ExecuteSubscript);

    /// <summary>
    /// Executes a single Subscript, in {subscript1; subscript2}
    /// </summary>
    /// <returns>True if the further execution of question is not necessary, i.e. the condition for displaying this line is not met. </returns>
    private static bool ExecuteSubscript(string script)
    {
        script = script.TrimStart();
        if (script.StartsWith("if"))
        {
            if (ExecuteCondition(script)) return true;
        }
        return false;
    }

    private static bool ExecuteCondition(string conditionScript)
    {
        string conditions = conditionScript.Substring(3).Trim();
    }

}*/
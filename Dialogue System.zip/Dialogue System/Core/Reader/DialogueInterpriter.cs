using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;

namespace DialogueSystem.Interpreter
{
    public static class DialogueInterpreter
    {
        private static DialogueFlow _df;
        private static string[] _allLines;
        private static int _lineNumber;
        private static string _line;
        private static int CurrentIndex = 0;
        
        
        private static IEnumerable<string> DoWhile()
        {
            while (true)
            {
                CurrentIndex++;
                if (CurrentIndex > 1000) throw new Exception($"{_allLines.Length}");

                _lineNumber++;
                if (_lineNumber >= _allLines.Length) yield break;
                
                _line = _allLines[_lineNumber];
                yield return _line;
            }
        }

        private static void SyntaxError(string message="")
        {
            throw new SyntaxErrorException($"Syntax Error at line {_lineNumber} {message}\n line: \"{_line}\" ");
        }

        public static DialogueFlow Read(string text)
        {
            _allLines = text.Replace("\r\n", "\n").Split('\n');
            if (_allLines.Length == 0)
            {
                return null;
            }

            _df = new DialogueFlow()
            {
                Questions = new Dictionary<string, Question>(),
                Variables = new Dictionary<string, VariableReference>(),
            };

            _lineNumber = -1;
            foreach (string line in DoWhile())
            {
                CurrentIndex++;
                if (CurrentIndex > 1000) throw new Exception($"{_allLines.Length}");

                if (Syntax.EmptyLine.IsMatch(line))
                {
                    continue;
                }

                Match match = Syntax.RegionStarter.Match(line);
                if (match.Success)
                {
                    string v = match.Groups[1].Value;
                    if (v == "Variables") ExtractVariables();
                    else if (v == "Dialogues") ExtractDialogues();
                    else SyntaxError();
                }
                else SyntaxError();
            }
            return _df;
        }

        private static void ExtractVariables()
        {
            foreach (string line in DoWhile())
            {
                CurrentIndex++;
                if (CurrentIndex > 1000) throw new Exception($"Ended-----> {_allLines.Length}");
                
                if (Syntax.EmptyLine.IsMatch(line)) continue;
                if (Syntax.RegionEnder.IsMatch(line))
                {
                    break;
                }

                Match match = Syntax.VariableDeclaration.Match(line);
                if (!match.Success) SyntaxError();

                GroupCollection groups = match.Groups;
                if (!string.IsNullOrEmpty(groups[2].Value)) SyntaxError($"Unexpected Token: {groups[2].Value}");
                
                string name = groups[1].Value;
                string value = groups[4].Value;
                if (groups[3].Value == "=")
                {
                    
                    if (string.IsNullOrEmpty(value)) SyntaxError("Variable Value Expected");
                    else if (value == "true")                                           _df.Variables.Add(name, new VariableReference(true, VariableType.Bool));
                    else if (value == "false")                                          _df.Variables.Add(name, new VariableReference(false, VariableType.Bool));
                    else if (value.StartsWith("'") && value.EndsWith("'"))              _df.Variables.Add(name, new VariableReference(value.Substring(1, value.Length-2), VariableType.String));
                    else if(value.Contains(".") && float.TryParse(value, out float vf)) _df.Variables.Add(name, new VariableReference(vf, VariableType.Float));
                    else if(int.TryParse(value, out int vi))                            _df.Variables.Add(name, new VariableReference(vi, VariableType.Int));
                    else SyntaxError($"Unexpected variable value: {value}");
                }
                else
                {
                    if (value.StartsWith("'") && value.EndsWith("'")) _df.Variables.Add(name, new VariableReference(value.Substring(1, value.Length-2), VariableType.Linked));
                    else SyntaxError("Expected linked variable name in quotes");
                }
            }
        }

        private static void ExtractDialogues()
        {
            Question currentQuestion = null;
            List<string> questionTexts = new List<string>();
            List<Option> options = new List<Option>();
            foreach (string line in DoWhile())
            {
                CurrentIndex++;
                if (CurrentIndex > 1000) throw new Exception($"{_allLines.Length}");
                if (Syntax.EmptyLine.IsMatch(line)) continue;

                if (ExtractQuestion(out Question newQuestion))
                {
                    AddQuestionToStack();
                    currentQuestion = newQuestion;
                }
                else if (ExtractOption(out Option opt))
                {
                    options.Add(opt);
                }
                else if (Syntax.RegionEnder.IsMatch(line)) break;
                else questionTexts.Add(line.TrimStart());
            }

            AddQuestionToStack();

            void AddQuestionToStack()
            {
                if (currentQuestion != null)
                {
                    currentQuestion.messages = questionTexts.ToArray();
                    currentQuestion.options = options.ToArray();

                    if (_df.Starter == null) _df.Starter = currentQuestion;
                    else _df.Questions.Add(currentQuestion.id, currentQuestion);
                    currentQuestion = null;
                }

                questionTexts.Clear();
                options.Clear();
            }
        }
        
        private static bool ExtractQuestion(out Question question)
        {
            Match match = Syntax.Question.Match(_line);
            if (!match.Success)
            {
                question = null;
                return false;
            }

            GroupCollection groups = match.Groups;
            if (!string.IsNullOrEmpty(groups[2].Value))
            {
                // If Group 2 is not null, then this is a syntax error. 
                SyntaxError($"Unexpected token \"{groups[2].Value}\"");
            }

            question = new Question
            {
                id = groups[1].Value
            };
            return true;
        }

        private static bool ExtractOption(out Option option)
        {
            Match match = Syntax.Option.Match(_line);
            if (!match.Success)
            {
                option = null;
                return false;
            }

            GroupCollection groups = match.Groups;
            if (!string.IsNullOrEmpty(groups[2].Value))
            {
                // If Group 2 is not null, then this is a syntax error. 
               SyntaxError($"Unexpected token \"{groups[2].Value}\"");
            }

            option = new Option(groups[1].Value, groups[3].Value);
            return true;
        }

        
        /*private static bool ExtractQuestionText(out QuestionText questionText)
        {
            _line = _line.TrimStart();

            /#1#/ Match the if command
            Match match = Syntax.CommandSplit.Match(_line);
            Condition condition = null;
            if (match.Success)
            {
                GroupCollection grps = match.Groups;
                if (!string.IsNullOrEmpty(grps[4].Value))
                {
                    // If Group 4 is not null, then this is a syntax error. 
                    SyntaxError($"Unexpected token \"{grps[4].Value}\"");
                }
                Operation operation = grps[2].Value switch
                {
                    "<" => Operation.Less,
                    "<=" => Operation.LessOrEqual,
                    "==" => Operation.Equal,
                    "!=" => Operation.NotEqual,
                    ">=" => Operation.GreaterOrEqual,
                    ">" => Operation.Greater,
                    _ => Operation.Equal
                };

                condition = new Condition() { variableName = grps[1].Value, operation = operation, comparedValue = grps[3].Value };
                _line = grps[5].Value;
            }#1#


            // Match the Commands other than If command
            Match match = Syntax.Command.Match(_line);
            if (!match.Success)
            {
                // If not match then there is no command in this line
                questionText = new QuestionText(_line.Replace("\\n", "\n"), Array.Empty<Command>(), condition);
                return true;
            }

            GroupCollection groups = match.Groups;
            List<Command> commands = new List<Command>();
            StringBuilder builder = new StringBuilder();
            int currentLength = 0;

            while (match.Success)
            {
                CurrentIndex++;
                if (CurrentIndex > 1000) throw new Exception($"{_allLines.Length}");
                
                
                
                if (!string.IsNullOrEmpty(groups[3].Value))
                {
                    // If Group 3 is not null, then this is a syntax error. 
                    SyntaxError($"Unexpected token \"{groups[3].Value}\"");
                }

                // Process the text before command
                string textBefore = groups[1].Value;
                currentLength += textBefore.Length;
                builder.Append(textBefore);

                // Process first command. 
                commands.Add(new Command(groups[2].Value, currentLength));

                // Update variables for next loop.
                _line = groups[4].Value;
                match = Syntax.Command.Match(_line);
                groups = match.Groups;
            }

            builder.Append(_line);
            questionText = new QuestionText(builder.ToString().Replace("\\n", "\n"), commands.ToArray(), condition);
            return true;
        }*/
    }
}
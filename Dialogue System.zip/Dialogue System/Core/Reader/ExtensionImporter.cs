using UnityEngine;
using System.IO;
using UnityEditor.AssetImporters;


[ScriptedImporter(1, "dsf")]
public class ExtensionImporter : ScriptedImporter
{
    public override void OnImportAsset(AssetImportContext ctx)
    {
        string text = File.ReadAllText(ctx.assetPath);
        TextAsset textAsset = new TextAsset(text);
        ctx.AddObjectToAsset("dialogue", textAsset);
        ctx.SetMainObject(textAsset);
    }
}

﻿using System.Text.RegularExpressions;


namespace DialogueSystem.Interpreter
{
    public static class Syntax
    {
        // public static readonly Regex EmptyLine = new Regex(@"^\s*$");
        public static readonly Regex EmptyLine = new Regex(@"^\s*$");

        /// <summary>
        /// Regex for Question Definition
        /// Group 1: Question ID
        /// Group 2: Syntax Error
        /// </summary>
        public static readonly Regex Question = new Regex(@"^\s*@(\w+)(.*)");

        /// <summary>
        /// Regex for Option Definition
        /// Group 1: Question ID
        /// Group 2: Syntax Error
        /// Group 3: Option Text
        /// </summary>
        public static readonly Regex Option = new Regex(@"^\s*\(\s*(\w*)\s*(.*)\s*\)\s*(.+)");
        
        public static readonly Regex RegionStarter = new Regex(@"^#(Variables|Dialogues)$");
        
        public static readonly Regex RegionEnder = new Regex(@"^#END$");

        /// <summary>
        /// Regex for declaring variable
        /// Group 1: Variable name
        /// Group 2: Syntax Error
        /// Group 3: Variable Category (defined with &lt;=&gt; or =)
        /// Group 4: variable value
        /// </summary>
        public static readonly Regex VariableDeclaration = new Regex(@"^\s*(\w+)\s*([^\s<]*)\s*(<=>|=)\s*(true|false|[0-9]+\.?[0-9]*|\'.*\')$");
        
        public static class Commands
        {
            // /// <summary>
            // /// Regex for QuestionText Definition
            // /// Group 1: Text before first command
            // /// Group 2: First Command Text
            // /// Group 3: Syntax Error
            // /// Group 4: Text After Command
            // /// </summary>
            // public static readonly Regex Command = new Regex(@"^([^\[]*)\[\s*([\w\.]+)\s*([^\]]*)\]\s*(.*)$");

            /// <summary>
            /// Regex for Goto Command
            /// Group 1: target id
            /// Group 2: Syntax Error
            /// </summary>
            public static readonly Regex Goto = new Regex(@"^goto_(\w*)\s*([^\]]*)$");

            /// <summary>
            /// Regex for Speed command
            /// Group 1: Speed value
            /// Group 2: Syntax Error
            /// </summary>
            public static readonly Regex Speed = new Regex(@"^speed_([0-9]+\.?[0-9]*)\s*([^\]]*)$");

            /// <summary>
            /// Regex for Wait command
            /// Group 1: duration
            /// Group 2: Syntax Error
            /// </summary>
            public static readonly Regex Wait = new Regex(@"^wait_([0-9]+\.?[0-9]*)\s*([^\]]*)$");
        }
        
        public static class Script
        {
            /// <summary>
            /// Regex for displaying questionText if a condition is satisfied
            /// Group 1: 
            /// Group 2: 
            /// Group 3: 
            /// Group 4: 
            /// Group 5: 
            /// </summary>
            public static readonly Regex Condition = new Regex(@"if (\w+) (<|<=|==|!=|=>|>) ");
            
            /// <summary>
            /// Regex for assigning a value to a predefined variable
            /// Group 1: 
            /// Group 2: 
            /// Group 3: 
            /// Group 4: 
            /// Group 5: 
            /// </summary>
            public static Regex SetValue = new Regex(@"");
        }
    }
}
using DialogueSystem;
using UnityEngine;

public class TheTestScript : MonoBehaviour
{
    [SerializeField] private TextAsset script;

    [ContextMenu("Start")]
    void Stsart()
    {
        DialoguesHandler.Instance.BeginConversation(script.text);
        // dialogueFlow = DialogueInterpreter.Read(script.text);
        // Debug.Log(JsonConvert.SerializeObject(dialogueFlow));
    }
}
